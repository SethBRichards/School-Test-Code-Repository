var basicfunctions_8h =
[
    [ "basicfunctions", "basicfunctions_8h.html#adae1183ea636c9408c1a330bbc35d8ec", null ],
    [ "bit_clr", "basicfunctions_8h.html#a7df406985987cc8633c9189d6e9b661c", null ],
    [ "bit_set", "basicfunctions_8h.html#a6d8080fedceb167e80fc512b2a440c43", null ]
];