var searchData=
[
  ['notes_39',['NOTES',['../lab4p1_8c.html#a0dcfd20e97e4c9ddc19888308ad18caf',1,'NOTES():&#160;lab4p1.c'],['../lab4p2_8c.html#a0dcfd20e97e4c9ddc19888308ad18caf',1,'NOTES():&#160;lab4p2.c']]],
  ['notes_40',['notes',['../lab4p1_8c.html#af710a1fbffd801dd83eecf0a2923efb3',1,'lab4p1.c']]]
];
