var searchData=
[
  ['basicfunctions_182',['basicfunctions',['../basicfunctions_8h.html#adae1183ea636c9408c1a330bbc35d8ec',1,'basicfunctions.h']]]
];
