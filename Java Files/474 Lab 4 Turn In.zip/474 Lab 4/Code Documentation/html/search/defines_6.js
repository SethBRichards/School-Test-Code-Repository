var searchData=
[
  ['g3_193',['G3',['../lab4p1_8c.html#aa18956b1e077aaf1b24bcb4b7eb841f5',1,'lab4p1.c']]]
];
