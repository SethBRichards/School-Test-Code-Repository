var searchData=
[
  ['task_5fa_222',['TASK_A',['../lab4p2_8c.html#a3613bf6c4ed28db1bdb03f44ee7c5eb2',1,'lab4p2.c']]],
  ['task_5fb_223',['TASK_B',['../lab4p2_8c.html#adf46e7ddd9f19a6f423b0b7cafb108db',1,'lab4p2.c']]],
  ['task_5fc_224',['TASK_C',['../lab4p2_8c.html#adcea7ff38113f44d9f65721f7a3ac8ee',1,'lab4p2.c']]],
  ['task_5fd_225',['TASK_D',['../lab4p2_8c.html#adbb84abccf95a77e93bb1e41cc9e8ab7',1,'lab4p2.c']]],
  ['thresh_5fhigh_226',['THRESH_HIGH',['../lab4p2_8c.html#a335f35357b04439cd8919d0bf9ab5b61',1,'lab4p2.c']]],
  ['thresh_5flow_227',['THRESH_LOW',['../lab4p2_8c.html#a4940f0d4d2a4c98755fc1b68614f32cb',1,'lab4p2.c']]],
  ['timerlib_228',['timerlib',['../timerlib_8h.html#ad9fb384616491436dce18b42d04bede5',1,'timerlib.h']]]
];
