var searchData=
[
  ['resumetaskb_131',['resumetaskB',['../lab4p2_8c.html#ab2767a4944df9a1e3d99664a8c4fc80d',1,'lab4p2.c']]],
  ['resumetaskc_132',['resumetaskC',['../lab4p2_8c.html#a4469443912277a230f2804df28ed24cd',1,'lab4p2.c']]]
];
