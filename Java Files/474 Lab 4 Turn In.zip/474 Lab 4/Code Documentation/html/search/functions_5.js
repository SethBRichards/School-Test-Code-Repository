var searchData=
[
  ['setup_133',['setup',['../lab4p1_8c.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;lab4p1.c'],['../lab4p2_8c.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;lab4p2.c']]],
  ['song_134',['song',['../lab4p2_8c.html#a3569072767e9aa4f65dccccd4a6c077c',1,'lab4p2.c']]],
  ['suspendtaskb_135',['suspendtaskB',['../lab4p2_8c.html#a621ffa9f16e0f69a12e5637fb35b226b',1,'lab4p2.c']]],
  ['suspendtaskc_136',['suspendtaskC',['../lab4p2_8c.html#aeb1269c910e733c6eb4d6299d91d5b9f',1,'lab4p2.c']]]
];
