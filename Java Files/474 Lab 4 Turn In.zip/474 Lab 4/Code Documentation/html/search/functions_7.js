var searchData=
[
  ['ultrasonic_5fget_148',['ultrasonic_get',['../ultrasonic_8c.html#a17d3e68994276eed8a37c0a7e360219f',1,'ultrasonic_get(int unit):&#160;ultrasonic.c'],['../ultrasonic_8h.html#a17d3e68994276eed8a37c0a7e360219f',1,'ultrasonic_get(int unit):&#160;ultrasonic.c']]],
  ['ultrasonic_5fsetup_149',['ultrasonic_setup',['../ultrasonic_8c.html#ad0fb51376f378a6aa9bfb8a78f691dfb',1,'ultrasonic_setup():&#160;ultrasonic.c'],['../ultrasonic_8h.html#ad0fb51376f378a6aa9bfb8a78f691dfb',1,'ultrasonic_setup():&#160;ultrasonic.c']]],
  ['us2cm_150',['us2Cm',['../ultrasonic_8c.html#ac99a17fdab3c5ee9fb5a2cfa90681724',1,'ultrasonic.c']]],
  ['us2in_151',['us2In',['../ultrasonic_8c.html#a9c098b755321d665359ace0577686b72',1,'ultrasonic.c']]],
  ['usensor_152',['usensor',['../lab4p2_8c.html#a80b2a97dbcf271600c9182d4fb8875e3',1,'lab4p2.c']]]
];
