var searchData=
[
  ['notes_164',['notes',['../lab4p1_8c.html#af710a1fbffd801dd83eecf0a2923efb3',1,'lab4p1.c']]]
];
