var searchData=
[
  ['targetfreq_176',['targetfreq',['../lab4p2_8c.html#a561ceefe4d404f38ef11ad11e26ad68c',1,'lab4p2.c']]],
  ['task3handle_177',['task3handle',['../lab4p1_8c.html#a3cc029a41a98c866acc450228abef8df',1,'lab4p1.c']]],
  ['task4handle_178',['task4handle',['../lab4p1_8c.html#a0d8f724685b31c5a7531e060e0f370c1',1,'lab4p1.c']]]
];
