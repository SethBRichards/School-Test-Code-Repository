var searchData=
[
  ['usensorhandle_179',['usensorhandle',['../lab4p2_8c.html#ab18c0f59c665b061c9d15e1fdc1a64d6',1,'lab4p2.c']]]
];
