var timerlib_8h =
[
    [ "CLK_FREQ", "timerlib_8h.html#aafc10c8bbf3d3c18ed615f24925bbb10", null ],
    [ "PRESCALER", "timerlib_8h.html#a0fac869d83ac1a584d6c45cf609f5fe7", null ],
    [ "timerlib", "timerlib_8h.html#ad9fb384616491436dce18b42d04bede5", null ],
    [ "timer_ISR_set", "timerlib_8h.html#ad667e2700bcd36e81d3493b74dc1bc06", null ],
    [ "timer_set", "timerlib_8h.html#a8e8bf158cec630f863261e12f7bcf99f", null ],
    [ "timer_setup", "timerlib_8h.html#a1769db82b14d338d8d4ca5ebbccf0379", null ]
];