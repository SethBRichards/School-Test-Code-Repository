/*ultrasonic.c/h
@file   ultrasonic.c/h
 *   @author    Diallo Wilson
 *   @author    Seth Richards
 *   @date      28-May-2021
 *   @brief   This c file contains functions to use the Ultrasonic senosr
 *   
 *  This c file contains basic functions to setup and return values from the Ultrasonic sensor.
 *  The units of the returned value can cm if given, inches by default. The ultrasonic sensor operates by 
 *  sending a quick soundwave out and measuring the time it takes to refelct back to it and calculate a distance
 *  based of the speed of sound.
 *  
 */

#include <Arduino.h>
#include "ultrasonic.h"
#include "basicfunctions.h"

/**
 * @brief Conversts microseconds to inches
 *
 * ms2In() takes the given microsecond pulse and converts it to inches with a predefined scaling factor
 * based on the speed of sound recovered from the ultrasonic sensor.
 *
 * @param us The duration of the pulse to be converted to inches
 * @return Returns a long expressing the distance to the nearest object in inches
 */
long us2In(long us) {
   return us / US_TO_IN;
}

/**
 * @brief Conversts microseconds to centimeters
 *
 * ms2Cm() takes the given microsecond pulse and converts it to centimeters with a predefined scaling factor
 * based on the speed of sound recovered from the ultrasonic sensor.
 *
 * @param mus The duration of the pulse to be converted to centimeters
 * @return Returns a long expressing the distance to the nearest object in centimeters
 */
long us2Cm(long us) {
   return us / US_TO_CM;
}

/**
 * @brief Sets up predefined ports for the ultrasonic sensor
 *
 * ultrasonic_setup() sets up the ping and echo pin to output and input respectively and confirms their outputs
 * start low.
 *
 * @return Returns nothing
 */
void ultrasonic_setup(){
  US_PORT_SET |= bit_set(PING_BIT);  //sets pins
  US_PORT |= bit_clr(PING_BIT);
}

/**
 * @brief Gets the distance in front of the ultrasonic sensor
 *
 * ultrasonic_get() sends a high frequency pulse out through the ultrasonic sensor and measures the
 * reflection of the pulsd to see when and how long the recieved pulse is recorded. The distance of that 
 * pulse can then be converted from microseconds to a unit of distance/
 *
 * @param unit The unit of distance returned: 1 for cm, anything else for inches
 * @return Returns the distance of the ultrasonic sensor in the unit specified
 */
long ultrasonic_get(int unit){
  US_PORT = bit_set(PING_BIT);                 // Send short pulse to emit through ultrasonic sensor
  delayMicroseconds(PING_DELAY);
  US_PORT = bit_clr(PING_BIT);
  if(unit){                                    // Unit conversion specification
    return us2Cm(pulseIn(ECHO_PIN, HIGH,0));   // Reads pulse to determine distance
  }
  else{
    return us2In(pulseIn(ECHO_PIN, HIGH,0));   // Reads pulse to determine distance
  }
}
