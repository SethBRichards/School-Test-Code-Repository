/*ultrasonic.h/h
@file   ultrasonic.h/h
 *   @author    Diallo Wilson
 *   @author    Seth Richards
 *   @date      28-May-2021
 *   @brief   This header file contains definitions related to getting a distance from the ultrasonic sensor
 *   
 *  This header file contains some constants for the pins and distance conversions for the ultrasonic sensor,
 *  including some function prototypes.
 *
 * Based on code found on https://www.tutorialspoint.com/arduino/arduino_ultrasonic_sensor.htm
 */


#ifndef ultrasonic.h
#define ultrasonic.h

//---------------------------------------------------------------------

#define US_PORT      PORTA
#define US_PORT_SET  DDRA
#define PING_BIT     1
#define ECHO_BIT     2
#define ECHO_PIN     24

#define PING_DELAY   10

#define US_TO_IN     148
#define US_TO_CM     58
	
#ifdef __cplusplus
extern "C" {
#endif

void ultrasonic_setup();
long ultrasonic_get(int unit);

#ifdef __cplusplus
}
#endif

//---------------------------------------------------------------------

#endif
