/*lab4p1.c/h
@file   lab4p1.c/h
 *   @author    Diallo Wilson
 *   @author    Seth Richards
 *   @date      28-May-2021
 *   @brief   This c file contains code for Lab 4 Part 1
 *   
 *   This ino file uses the FreeRTOS task scheduler system to perform 4 basic tasks.
 *        1 - Blink the built in LED forever
 *        2 - Play a tune 3 times
 *        3 - Send a pointer to another task and time the average time of that task's oepration 5 times
 *        4 - Use pointer to compute FFT on random data
 */


#include <arduinoFFT.h>         ///< Library for FFT computations
#include <Arduino_FreeRTOS.h>   ///< Library for FreeRTOS
#include <queue.h>              ///< Library for FreeRTOS queue system
#include <task.h>               ///< Library for FreeRTOS task notification system

#include "basicfunctions.h"    ///< Library for basic register setting
#include "timerlib.h"          ///< Library for setting up Arduino timer for tones

#define LED_BUILTIN_PORT       PORTB  ///< Port for built in LED @see LED_BUILTIN_PORT_BIT
#define LED_BUILTIN_PORT_SET   DDRB   ///< I/O Register for built in LED @see LED_BUILTIN_PORT_BIT
#define LED_BUILTIN_PORT_BIT   7      ///< Bit number in ports for LED
#define LED_ON                 100    ///< Time for the LED on period
#define LED_OFF                200    ///< Time for the LED off period

#define SPKR_ON_PERIOD       500  ///< Speaker On time for 0.5s, converted to 2ms
#define SPKR_ON_PERIOD_LONG  1250 ///< Speaker On long time for 1s, converted to 2ms
#define SPKR_OFF_PERIOD      1500 ///< Speaker On time for 4s, converted to 2ms
#define NOTES                5    ///< Notes in song
#define SPRK_REPEAT          3    ///< Times the song plays before suspending

#define D4 293      ///< Frequency of D4, 293 Hz
#define E4 329      ///< Frequency of E4, 329 Hz
#define C4 261      ///< Frequency of C4, 261 Hz
#define C3 130      ///< Frequency of C3, 130 Hz
#define G3 196      ///< Frequency of G3, 196 Hz

#define RANDOM_INTS         512 ///< Number of random numbers in array
#define RANDOM_UPPER_BOUND  56  ///< Upper range of random numbers
#define FIVE                5   ///< Number of FFT computations to perform
#define SEED                6   ///< Seed for random numbers for consistency

TaskHandle_t task3handle = NULL;            ///< Handle for Task 3 for notifications
TaskHandle_t task4handle = NULL;            ///< Handle for Task 4 for notifications

static QueueHandle_t    Q_pointer_holder;   ///< Queue object
static arduinoFFT FFT = arduinoFFT();       ///< FFT object

int notes[] = {D4*2, E4*2, C4*2, C3*2, G3*2,0};                                                         ///< Order of notes played in song
int delaySPKR[] = {SPKR_ON_PERIOD,SPKR_ON_PERIOD,SPKR_ON_PERIOD,SPKR_ON_PERIOD,SPKR_ON_PERIOD_LONG};    ///< Associated Delays for each tone

double randomArray[RANDOM_INTS];   ///< Array of random data to do FFT on

// define task prototypes
void taskRT1( void *pvParameters );
void taskRT2( void *pvParameters );
void taskRT3( void *pvParameters );
void taskRT4( void *pvParameters );


// the setup function runs once when you press reset or power the board
void setup() {
  
  // initialize serial communication at 9600 bits per second:
  
  Serial.begin(19200);
  
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB, on LEONARDO, MICRO, YUN, and other 32u4 based boards.
  } 

  randomSeed(SEED);                        // Pseudo random (seeded values)
  for(int i = 0;i < RANDOM_INTS;i++){   // Populates array with random values to compute FFT for
    randomArray[i] = random(RANDOM_UPPER_BOUND);
  }

  Q_pointer_holder = xQueueCreate(1, sizeof(double *)); // Creates queue to store value size of a pointer for double

  // Now set up two tasks to run independently.
  xTaskCreate(
    taskRT1
    ,  "Blink"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  3  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  NULL );

  xTaskCreate(
    taskRT2
    ,  "Song"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  3  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  NULL );

    xTaskCreate(
    taskRT3
    ,  "Sender"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  2  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  &task3handle );

    xTaskCreate(
    taskRT4
    ,  "FFTer"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  0  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  &task4handle );

  vTaskStartScheduler();

}

void loop()
{
  // Empty. Things are done in Tasks.
}

/*---------------------- Tasks ---------------------*/

/**
 * @brief Blinks the on board LED forever
 *
 * taskRT1() flashes the Arduino Mega's on board LED on for 100ms and off for 200ms in
 * an infinitely repeating series. This task is built through FreeRTOS tasks and is therefore preemptive.
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 */
void taskRT1(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params

  // initialize digital LED_BUILTIN on pin 13 as an output.
  LED_BUILTIN_PORT_SET |=bit_set(LED_BUILTIN_PORT_BIT);

  for (;;) // A Task shall never return or exit.
  {
    LED_BUILTIN_PORT |=bit_set(LED_BUILTIN_PORT_BIT);               // Sets bultin LED to high
    vTaskDelay( LED_ON / portTICK_PERIOD_MS );                      // wait for one second
    LED_BUILTIN_PORT &=bit_clr(LED_BUILTIN_PORT_BIT);               // Sets bultin LED to low
    vTaskDelay( LED_OFF / portTICK_PERIOD_MS );                     // wait for one second
  }
}

/**
 * @brief Plays the tune from Close Encounters three times, with pauses
 *
 * taskRT2() sets a speaker to emitt tones correpsonding to the frequencies and timings of the Close Encounters
 * theme 3 times before halting. This task is built through FreeRTOS tasks and is therefore preemptive.
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 */
void taskRT2(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params

  timer_setup(4,0,1);                                          // sets up timer 4  to output at pin 6
  int state = 0;
  for (int i = 0;i < SPRK_REPEAT;i++)                          // A Task shall repeat only 3 times
  {
    for(int j = 0;j <= NOTES;j++){
      timer_set(4,notes[state]);                               // Sets registers to play given frequency
      vTaskDelay( delaySPKR[state] / portTICK_PERIOD_MS );     // Corresponding hold for each tone
      state++;                                                 // Cycles through tones and associated pauses
    }
    state = 0;                                                 // Resets tone state
    vTaskDelay( SPKR_OFF_PERIOD / portTICK_PERIOD_MS );        // Silence for 1.5 seconds
    
  }
  vTaskSuspend( NULL );                                        // Suspends task 2 (itself) after completion
}


/**
 * @brief Computes average time of FFT computation with data sent to another task
 *
 * taskRT3() sends a pointer of a random signal to another task to do an FFT 5 times, and will wait for
 * those occurances to track the total time of computations before dividing by the number to find the average computation
 * time including delivery. This task is built through FreeRTOS tasks and is therefore preemptive.
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 */
void taskRT3(void *pvParameters)  {
 (void) pvParameters;  // allocate stack space for params
  static double *randomArrayPointer = randomArray;             // Pointer to array of 512 random numbers
  static long int start = millis();                            // Gets time in ms of when process starts (Sandesh said millis is fine)
  
  for(int i = 0; i < FIVE;i++){                                // Does FFT process 5 times

    xQueueSendToBack(Q_pointer_holder,randomArrayPointer, 0);  // Puts pointer to random array in queue for task 4
    xTaskNotifyGive(task4handle);                              // Unblocks task 4 to do FFT
    ulTaskNotifyTake(pdTRUE, portMAX_DELAY);                   // Waits for task 4 to send next pointer for proper timing
    
  }
  
  Serial.print("Average FFT Time: ");                          // Prints out the average FFT processing time
  Serial.print((millis()-start)/FIVE);                         // Total average time = (current time - start time)/times
  Serial.print(" ms");
  
  vTaskSuspend(NULL);                                          // Suspends task 3 (itself) after FIVE FFTs
  vTaskSuspend(task4handle);                                   // Suspends task 4 after task 3 suspended

}

/**
 * @brief Computes a FFT from queued data
 *
 * taskRT4() recieves data from task 3 in a FreeRTOS queue to perform a computation on, before signalling that it is complete 
 * by unblocking task 3. This task is built through FreeRTOS tasks and is therefore preemptive.
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 */
void taskRT4(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params
  static double queueReciever[RANDOM_INTS] = {0};                       // Real part of signal = random array once queued
  static double vImag[RANDOM_INTS] = {0};                                  // Imaginary part of signal = 0
   
  for(;;){                                                              // Always waiting for task 3
   ulTaskNotifyTake(pdTRUE, portMAX_DELAY);                             // Waits for task3 to unblock
   xQueueReceive(Q_pointer_holder,queueReciever,portMAX_DELAY);         // Gets random array from task 3 in queue
   FFT.Compute(queueReciever, vImag, RANDOM_INTS, FFT_FORWARD); // Computes FFT 
   xTaskNotifyGive(task3handle);                                        // Ublocks task 3 to activate again
  }

}