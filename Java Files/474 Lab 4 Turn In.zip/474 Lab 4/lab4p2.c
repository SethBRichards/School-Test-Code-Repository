/*lab4p2.c/h
@file   lab4p2.c/h
 *   @author    Diallo Wilson
 *   @author    Seth Richards
 *   @date      29-May-2021
 *   @brief   This c file contains code for Lab 4 Part 2 Project
 *   
 *   This ino file uses the FreeRTOS task scheduler system to
 *        1RT - Blink the built in LED forever
 *        A - Set frequency bounds, target frequency, and linear interpolation for distance to frequency conversion
 *        B - Play target frequency
 *        C - Make a guess frequency usign ultrasonic sensor as input
 *        D - Check to see if the guess is close enough to the target
 *        
 *        usensor - get the target distance from the ultrasonic sensor
 *        song    - play a corresponding song to pass/fail criteria
 *        key_get - get the keypad values and manage high level task scheduling
 *        
 *        Essentially, the user inputs a frequency range for the speaker to play relative to the distance measured
 *        by the ultrasonic sensor, and the user must control that distance to match the input target frequency output.
 *        Failing to do so will play a failing tone, and suceeding will play a victory song. It's a game.
 */


#include <Arduino_FreeRTOS.h>   ///< Library for FreeRTOS
#include <Keypad.h>             ///< Library for Keypad found on Github
#include <LiquidCrystal.h>      ///< Library for LCD in Arduino Libraries

#include "basicfunctions.h"    ///< Library for basic register setting
#include "timerlib.h"          ///< Library for setting up Arduino timer for tones
#include "ultrasonic.h"        ///< Library for setting up ultrasonic sensor

#define LED_BUILTIN_PORT       PORTB  ///< Port for built in LED @see LED_BUILTIN_PORT_BIT
#define LED_BUILTIN_PORT_SET   DDRB   ///< I/O Register for built in LED @see LED_BUILTIN_PORT_BIT
#define LED_BUILTIN_PORT_BIT   7      ///< Bit number in ports for LED
#define LED_ON                 100    ///< Time for the LED on period
#define LED_OFF                200    ///< Time for the LED off period

#define SPKR_ON_PERIOD       500  ///< Speaker On time for 0.5s, converted to 2ms
#define NOTES                6    ///< Notes in song

#define STRING_HIGH_FREQ "Enter High Freq:"  ///< Message prompting for high frequnecy bound
#define STRING_LOW_FREQ  "Enter Low Freq:"   ///< Message prompting for low frequnecy bound
#define STRING_HIGH      "H: "               ///< String for high freq
#define STRING_LOW       "L: "               ///< String for low freq
#define STRING_OUT       "O: "               ///< String for target freq
#define STRING_SPACE     " "                 ///< String for spacing
#define STRING_CM        " CM"               ///< String for centimeters

#define STRING_GIVEN_FREQ "Enter Freq Out:"  ///< Message prompting for target frequnecy 
#define STRING_FREQ "F:"                     ///< String for target frequency
#define STRING_SUCCESS "You did it!"         ///< String for successful guess
#define STRING_FAILURE "Fail"                ///< String for failed guess
#define STRING_FREQ_IN "Your Freq was: "     ///< String for guessed frequency

#define CM_HIGH 30  ///< Assumed max distance for freq linear interpolation
#define CM_LOW  5   ///< Assumed min distance for freq linear interpolation

#define A_INPUTS  12  ///< Number of key inputs to complete task A

#define TASK_A  'A'  ///< Char corresponding to trigger task A from key
#define TASK_B  'B'  ///< Char corresponding to trigger task B from key
#define TASK_C  'C'  ///< Char corresponding to trigger task C from key
#define TASK_D  'D'  ///< Char corresponding to trigger task D from key

#define THRESH_HIGH 1.1  ///< Upper guessed frequency percent tolerance threshold value
#define THRESH_LOW  0.9  ///< Lower guessed frequency percent tolerance threshold valu

//LiquidCrystal lcd(RS, E, D4, D5, D6, D7);
LiquidCrystal lcd(8,9,5,4,3,2);     ///< LCD constructor pin mapping

TaskHandle_t setBounds = NULL;            ///< Handle for task A calls
TaskHandle_t playFreq = NULL;             ///< Handle for task B calls
TaskHandle_t playFreqDist = NULL;         ///< Handle for task C calls
TaskHandle_t usensorhandle = NULL;        ///< Handle for ultrasonic sensor task
TaskHandle_t songhandle = NULL;           ///< Handle for pass/fail song task
TaskHandle_t scheduler = NULL;            ///< Handle for get key task
TaskHandle_t check = NULL;                ///< Handle for task D calls

const byte ROWS = 4;  ///< Number of rows on the keypad
const byte COLS = 4;  ///< Number of columns on the keypad

char hexaKeys[ROWS][COLS] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
}; ///< Map for the keys on the keypad
int state = 0;
byte rowPins[ROWS] = {34, 35, 36, 37};  ///< rowPins
byte colPins[COLS] = {38, 39, 40, 41};  ///< colPins

Keypad customKeypad = Keypad(makeKeymap(hexaKeys), rowPins, colPins, ROWS, COLS);  ///< Keypad constructor


int vnotes[] = {200*2,220*2,210*2,220*2,230*2,260*2};                                                             ///< Order of notes played in victory song
int fnotes[] = {200,190,180,170,180,150};                                                                         ///< Order of notes played in fail song
int delaySPKR[] = {SPKR_ON_PERIOD,SPKR_ON_PERIOD,SPKR_ON_PERIOD,SPKR_ON_PERIOD,SPKR_ON_PERIOD,SPKR_ON_PERIOD};    ///< Associated Delays for each tone

int frequency = 100;   ///< Global guess frequency
int targetfreq = 100;  ///< Global target frequency
int distance = 0;      ///< Global distance from ultrasonic sensor
char passKey;          ///< Global key to pass to tasks for inputs
int freq_slope = 16;   ///< Global linear interpolation slope for dist to freq (assume 100-500 Hz)
int freq_yint = 20;    ///< Global linear interpolation y intercept for dist to freq (assume 100-500 Hz)

int pass = 0;          ///< Global flag for pass/fail for target to guessed frequency

// define task prototypes
void taskRT1( void *pvParameters );
void usensor( void *pvParameters );
void taskA( void *pvParameters );
void taskB( void *pvParameters );
void taskC( void *pvParameters );
void taskD( void *pvParameters );


// the setup function runs once when you press reset or power the board
void setup() {
  
  // initialize serial communication at 9600 bits per second:
  
  Serial.begin(19200);
  
  lcd.begin(16, 2);     // sets up LCD pins
  timer_setup(4,0,1);   // sets up timer 4 to output pin 6

  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB, on LEONARDO, MICRO, YUN, and other 32u4 based boards.
  } 
  
  lcd.begin(16, 2);

  // Now set up two tasks to run independently.
  xTaskCreate(
    taskRT1
    ,  "Blink"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  2  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  NULL );

  xTaskCreate(
    usensor
    ,  "Ultrasonic task"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  1  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  &usensorhandle );
   xTaskCreate(
    song
    ,  "Song if win"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  1  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  &songhandle );
  xTaskCreate(
    taskA
    ,  "Sets Freq to Dist Bounds"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  1  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  &setBounds );
  xTaskCreate(
    taskB
    ,  "Play Frequnecy Task"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  1  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  &playFreq );

   xTaskCreate(
    taskC
    ,  "Play Frequnecy Task from Distance"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  1  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  &playFreqDist );
   xTaskCreate(
    taskD
    ,  "Guess Frequency"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  1  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  &check );
    xTaskCreate(
    key_get
    ,  "Fast Display Task"   // A name just for humans
    ,  128  // This stack size can be checked & adjusted by reading the Stack Highwater
    ,  NULL
    ,  0  // Priority, with 3 (configMAX_PRIORITIES - 1) being the highest, and 0 being the lowest.
    ,  &scheduler );


  vTaskStartScheduler(); // Operates created tasks preemptivly using FreeRTOS

}

void loop()
{
  // Empty. Things are done in Tasks.
}

/*---------------------- Tasks ---------------------*/

void key_get(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params

  char key = "-";   // Default input key should cause issues if keypad failure
  int flag = 0;     // Mode Flag: 1 for input number, 0 for input task
  int counter = 0;  // Counts inputs for input task transfer

  for(;;)                          
  {
    
    key = customKeypad.getKey();                   // Gets the entered key value to activate functions

    if(flag){                                      // Input Mode: Allows for key inputs to go to tasks instead of scheduler
      if(key != NO_KEY){
        passKey = key;
        counter++;
        if(counter == A_INPUTS){                   // Allows 12 inputs(3 four digit nums) to pass to task A before exiting
          flag = 0;                                // Ends inputting mode
          counter = 0;
        }
      }
    }
    else if(key == TASK_A){                        // Task A Calls (Self Suspending)
      suspendtaskB();                              // Suspends other tasks
      suspendtaskC();
      vTaskResume(setBounds);                      // Calls task A
      flag = 1;                                    // Sets Flag for input mode
    }
    else if(key == TASK_B){                        // Task B Calls
      suspendtaskC();                              // Suspend other tasks
      resumetaskB();
      vTaskSuspend(check); 
    }
    else if(key == TASK_C){                        // Task C Calls
      lcd.clear();
      suspendtaskB();                              // Suspend other tasks
      resumetaskC();                               // Calls task c task
      
    }
    else if(key == TASK_D){                        // Task D Calls (Self Suspending)
      suspendtaskB();
      suspendtaskC();
      vTaskResume(check);
    }
    
    key = NO_KEY;
    vTaskDelay( 30 / portTICK_PERIOD_MS );
  }
}





/**
 * @brief Blinks the on board LED forever
 *
 * taskRT1() flashes the Arduino Mega's on board LED on for 100ms and off for 200ms in
 * an infinitely repeating series. This task is built through FreeRTOS tasks and is therefore preemptive.
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 */
void taskRT1(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params

  // initialize digital LED_BUILTIN on pin 13 as an output.
  LED_BUILTIN_PORT_SET |=bit_set(LED_BUILTIN_PORT_BIT);

  for (;;) // A Task shall never return or exit.
  {
    LED_BUILTIN_PORT |=bit_set(LED_BUILTIN_PORT_BIT);               // Sets bultin LED to high
    vTaskDelay( LED_ON / portTICK_PERIOD_MS );                      // wait for one second
    LED_BUILTIN_PORT &=bit_clr(LED_BUILTIN_PORT_BIT);               // Sets bultin LED to low
    vTaskDelay( LED_OFF / portTICK_PERIOD_MS );                     // wait for one second
  }
}


/**
 * @brief Gets inputs for freqency target and bounds
 *
 * taskA() gets 3 four digit number inputs for the upper bound frequency, lower bound frequency,
 * and target frequency to determine the linear interpolation parameters for the ultrasonic
 * sensor's measured distance to output frequency conversion. This function uses a state machine to wait
 * for the inputs from the task @see key_get()
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 * @warning This task is pre-emptive, however it must receive 12 inputs before other tasks can be activated
 */
void taskA(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params
  
  static int state = 0;    // Sets behavior of LCD and inputs based on step
  char currKey;            // Gets current key for input
  int upper;               // High value for frequency bound
  int lower;               // Low value for frequency bound
  int hold[4];             // Containter for each input in relative position for frequency
  int holdCount = 0;       // Tracks entered digits
  
  vTaskSuspend(setBounds);                                                 // Defaults to suspended
  for(;;)                          
  {
      if(state == 0){                                                      // Gives bound prompt and sets up for freq input
        lcd.clear();
        lcd.print(STRING_HIGH_FREQ);
        lcd.setCursor(0,1);
        state++;
      }
      else if (state == 1){
        currKey = passKey;
        
        if(currKey != NO_KEY){                                             // Gets non empty input key
          lcd.print(currKey);
          hold[holdCount] = currKey - 48;                                  // Converts from char int to ascii char (ex. 50 - > "2")
          holdCount++;
        }
        passKey = NO_KEY;                                                  // resets taken key input
        if(holdCount == 4){                                                // gets 4 digit number for bound
          holdCount = 0;
          upper = hold[0] * 1000 + hold[1] * 100 + hold[2] * 10 + hold[3]; //converts array of digits + positions to number
          state++;
        }
      }
      else if(state == 2){                                                 // Gives bound prompt and sets up for freq input
        lcd.clear();
        lcd.print(STRING_LOW_FREQ);
        lcd.setCursor(0,1);
        state++;
      }
      else if (state == 3){
        currKey = passKey;
        
        if(currKey != NO_KEY){                                             // Gets non empty input key
          lcd.print(currKey);
          hold[holdCount] = currKey - 48;                                  // Converts from char int to ascii char (ex. 50 - > "2")
          holdCount++;
        }
        passKey = NO_KEY;                                                  // resets taken key input
        if(holdCount == 4){                                                // gets 4 digit number for bound
          holdCount = 0;
          lower = hold[0] * 1000 + hold[1] * 100 + hold[2] * 10 + hold[3]; //converts array of digits + positions to number
          state++;
        }
      }
            else if(state == 4){                                           // Gives bound prompt and sets up for freq input
        lcd.clear();
        lcd.print(STRING_GIVEN_FREQ);
        lcd.setCursor(0,1);
        state++;
      }
      else if (state == 5){
        currKey = passKey;
        
        if(currKey != NO_KEY){                                             // Gets non empty input key
          lcd.print(currKey);
          hold[holdCount] = currKey - 48;                                  // Converts from char int to ascii char (ex. 50 - > "2")
          holdCount++;
        }
        passKey = NO_KEY;                                                  // resets taken key input
        if(holdCount == 4){                                                // gets 4 digit number for bound
          holdCount = 0;
          targetfreq = hold[0] * 1000 + hold[1] * 100 + hold[2] * 10 + hold[3]; //converts array of digits + positions to number
          state++;
        }
      }
      else if (state == 6){                                                // Prints out given bounds and target frequencies for verification
        lcd.clear();
        frequencyCalculator(upper,lower);
        lcd.print(STRING_HIGH);
        lcd.print(upper);
        lcd.print(STRING_SPACE);
        lcd.print(STRING_LOW);
        lcd.print(lower);
        lcd.setCursor(0,1);
        lcd.print(STRING_OUT);
        lcd.print(targetfreq);
        state = 0;
        vTaskSuspend(NULL);
      }
      
      vTaskDelay( 200 / portTICK_PERIOD_MS );
  }
}

/**
 * @brief Displays and outputs the previously entered target frequency
 *
 * taskB() displays the target frequency from task A on the LCD while playing
 * out the target frequency on the speaker
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 */
void taskB(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params

  vTaskSuspend(playFreq);
  for(;;)                          
  {
      lcd.clear();
      lcd.print(STRING_FREQ);                   // Prints out given target frequency
      lcd.setCursor(0,1);
      lcd.print(targetfreq);
      timer_set(4,targetfreq);                  // Plays target frequency
      vTaskDelay( 200 / portTICK_PERIOD_MS );
  }
}

/**
 * @brief Outputs the distance to target in cm and plays corresponding frequency
 *
 * taskC() gets the distance to the target from the ultrasonic sensor and plays a corresponding
 * frequency output from the linear interpolation of previously established frequency and distance bounds
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 */
void taskC(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params

  vTaskSuspend(playFreqDist);
  for(;;)                          
  {    
      lcd.clear();
      lcd.print(distance);                    // Prints out current target distance in cm
      lcd.print(STRING_CM);
      timer_set(4,frequency);                 // Outputs current interpolated frequency from target distance
      vTaskDelay( 20 / portTICK_PERIOD_MS );
  }
}

/**
 * @brief Plays a song for the user based on their guess and tells them their guessed frequency
 *
 * taskD() will compare the input target frequency to the guessed frequency and play a victory song if
 * they are within 10% range, and a failing song if not. This will also be dispalyed on the LCD screen
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 */
void taskD(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params
  

  frequency = 100;  // default input freq for demo
  targetfreq = 100; // default target freq for demo
  
  vTaskSuspend(check);  // Defaults to suspended
  for(;;)                          
  {
      double closePercent = (double)frequency/targetfreq;                 // Calculates relative percent diff between guess and target freq

      lcd.clear();                                                        // Gives the frequency guessed
      lcd.print(STRING_FREQ_IN);
      lcd.setCursor(0,1);
      lcd.print(frequency);
      lcd.print(STRING_SPACE);
      
      if(closePercent > THRESH_LOW && closePercent < THRESH_HIGH){        // Determiens guess pass/fail by 10% threshold
        pass = 1;
        lcd.print(STRING_SUCCESS);                                        // Prints success if within thresh
      }
      else{
        pass = 0;
        lcd.print(STRING_FAILURE);                                        // Prints fail if outside thresh
      }
      
      vTaskResume(songhandle);                                            // Plays corresponding result song
      vTaskSuspend(check);                                                // Quits itself
  }
}

/**
 * @brief Gets the distance from the ultrasonic sensor and maps it to an output frequency
 *
 * usensor() uses our created ultrasonic library to send a soundwave through the sensor and measured its time
 * to get the distance to an object in front of it. This distance updates the global variable @see distance .
 * Then, using the linear interpolation paramaters given in @see taskA(), maps that distance to a frequency
 * and updates the global @see frequency. This process repeats every 20ms to track the target without audible glitches
 * resulting from improper timing.
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 * @warning Audible glitches can occur if the target is not properly oriented to reflect sound waves
 */
void usensor(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params

  double dist = 0;
  ultrasonic_setup();                                 // Sets up ultrasonic sensor pins and methods
  vTaskSuspend(usensorhandle);                        // Defaults to suspended                  
  for(;;)                          
  {
      dist = ultrasonic_get(1);                       // Uses ultrasonic sensor to get distance to target in cm
      distance = dist;                                // Updates global distance var
      frequency = (int)dist * freq_slope + freq_yint; // Modifies cm into bounded frequency from linear interpolation
      vTaskDelay( 20 / portTICK_PERIOD_MS );          // Updates distance every 20ms
  }
}

/**
 * @brief Plays a the corresponding song
 *
 * song() will play a song based on the flag @see pass , and point to the proper notes to be output on the speaker
 *
 * @param *pvParameters Pointer for task parameters (unused)
 * @return Returns nothing
 */
void song(void *pvParameters){
 // (void) pvParameters;  // allocate stack space for params

  int state = 0;
  int *notes;                                                  // Pointer to correpsonding song for pass/fail
  vTaskSuspend(songhandle);
  for (;;)                         
  {
    if(pass){                                                 // Victory song if pass flag, fail song if not (points to)
      notes = vnotes;
    }
    else{
      notes = fnotes;
    }
    
    for(int j = 0;j <= NOTES;j++){
      timer_set(4,notes[state]);                               // Sets registers to play given frequency
      vTaskDelay( delaySPKR[state] / portTICK_PERIOD_MS );     // Corresponding hold for each tone
      state++;                                                 // Cycles through tones and associated pauses
    }
    state = 0;                                                 // Resets tone state
    timer_set(4,0);
    vTaskSuspend( NULL );                                      // Suspends itself after completion
  }
                                          
}

/*---------------------- Non-Task Functions ---------------------*/

/**
 * @brief Creates linear interpolation variables from given high and low frequency bounds for distance to frequency conversion
 *
 * frequencyCalculator() calculates linear interpolation variables for the given frequency upper and lower bounds for an 
 * assumed distance to frequency conversion based on the useable range of 5-30cm, and solving the equation y=mx + b for both
 * bounds. This map creates a slope and y intercept to set all distances with a correlated frequency for task C.
 * 
 * @param upper is the upper bound of the frequency output mapped to 30 cm
 * 
 * @return Returns nothing but updates globals @see freq_slope & @see freq_yint
 * @warning Boundary frequencies are not hard and simply provide reference ranges
 * @warning No check for nonsensical variable returns
 */
void frequencyCalculator(int upper, int lower){
  freq_slope = (upper - lower)/(CM_HIGH - CM_LOW);
  freq_yint = ((-1*upper)/CM_LOW) + ((CM_LOW+1)*lower/CM_LOW);
}

/**
 * @brief Resumes all task B operations
 *
 * resumetaskB() resumes the task that plays the associated converted frequency, 
 * while resetting the speaker to no output tone
 * 
 * @return Returns nothing
 */
void resumetaskB(){
  vTaskResume(playFreq);
  timer_set(4,0);
}

/**
 * @brief Halts all task B operations
 *
 * suspendtaskB() suspends the task that plays the associated converted frequency, 
 * while setting the speaker to no output tone
 * 
 * @return Returns nothing
 */
void suspendtaskB(){
  vTaskSuspend(playFreq);
  timer_set(4,0);
}

/**
 * @brief Resumes all task C operations
 *
 * resumetaskC() resumes the ultrasonic sensor measurment task and the task that 
 * plays the associated converted frequency, while resetting the speaker to no output tone
 * 
 * @return Returns nothing
 */
void resumetaskC(){
  vTaskResume(playFreqDist);
  vTaskResume(usensorhandle);
  timer_set(4,0);
}

/**
 * @brief Halts all task C operations
 *
 * suspendtaskC() suspends the ultrasonic sensor measurment task and the task that 
 * plays the associated converted frequency, while setting the speaker to no output tone
 * 
 * @return Returns nothing
 */
void suspendtaskC(){
  vTaskSuspend(playFreqDist);  //FreeRTOS call to suspend playing frequency task
  vTaskSuspend(usensorhandle);
  timer_set(4,0);
}